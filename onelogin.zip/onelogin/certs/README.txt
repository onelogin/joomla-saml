Place here your X.509 certs. Naming them sp.crt and sp.key

Protect this folder, the private key must not be published by the server