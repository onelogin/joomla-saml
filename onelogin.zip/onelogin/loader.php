<?php

/*
 *  @copyright   Copyright (C) 2021 OneLogin, Inc. All rights reserved.
 *  @license     MIT
 */

require_once __DIR__ . '/vendor/autoload.php';
require_once __DIR__ . '/saml_joomla.php';
